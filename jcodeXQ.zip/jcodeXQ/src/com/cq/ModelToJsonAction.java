package com.cq;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

import com.alibaba.fastjson.JSONObject;

import com.cq.file.JsonFileGenerator;
import com.intellij.ide.highlighter.JavaClassFileType;
import com.intellij.ide.highlighter.JavaFileType;
import com.intellij.notification.Notification;
import com.intellij.notification.NotificationDisplayType;
import com.intellij.notification.NotificationGroup;
import com.intellij.notification.NotificationType;
import com.intellij.notification.Notifications;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.CommonDataKeys;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiFile;
import com.intellij.psi.util.PsiUtil;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;

import static com.intellij.openapi.actionSystem.CommonDataKeys.PSI_ELEMENT;

/**
 * @author cq
 */
@Slf4j
public class ModelToJsonAction extends AnAction {
    public static final NotificationGroup notificationGroup = new NotificationGroup("junitCode",
        NotificationDisplayType.BALLOON, true);

    ModelToJsonAction(){
        getTemplatePresentation().setText("generate json data");
    }

    /**
     * @see AnAction#actionPerformed(AnActionEvent)
     */
    @Override
    public void actionPerformed(AnActionEvent e) {
        PsiClass topLevelClass = PsiUtil.getTopLevelClass(e.getData(PSI_ELEMENT));
        Map<String, Object> fieldMap = Arrays.stream(topLevelClass.getAllFields()).collect(
            Collectors.toMap(field -> field.getName(), field -> JsonFileGenerator.typeResolve(field.getType(), 0),(a,b)->b));
        String s = JSONObject.toJSONString(fieldMap, true);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        StringSelection selection = new StringSelection(s);
        clipboard.setContents(selection, selection);
        String message = topLevelClass.getName() + "data as json already copied to clipboard";
        Notification success = notificationGroup.createNotification(message, NotificationType.INFORMATION);
        Notifications.Bus.notify(success, e.getProject());
    }

    /**
     * @see AnAction#update(AnActionEvent)
     */
    @Override
    public void update(@NotNull AnActionEvent e) {
        e.getPresentation().setEnabled(true);
        return;
//        super.update(e);
//        PsiFile psiFile = e.getData(CommonDataKeys.PSI_FILE);
//        FileType fileType = psiFile.getFileType();
//        if (!((fileType instanceof JavaFileType)||(fileType instanceof JavaClassFileType))) {
//            e.getPresentation().setEnabled(false);
//            return;
//        }

    }
}
