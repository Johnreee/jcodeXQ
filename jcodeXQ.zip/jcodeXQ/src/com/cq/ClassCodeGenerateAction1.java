package com.cq;

import com.cq.file.CodeGenerator;
import com.cq.file.FileCreateTask;
import com.cq.file.FileUtils;
import com.cq.toolwindow.CodeGeneratorDialog;
import com.cq.valuegenerator.impl.ValueContext;
import com.intellij.ide.highlighter.JavaFileType;
import com.intellij.notification.impl.widget.IdeNotificationArea;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.CommonDataKeys;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.fileEditor.OpenFileDescriptor;
import com.intellij.openapi.fileTypes.FileType;
import com.intellij.openapi.project.DumbAwareAction;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.LocalFileSystem;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.*;
import com.intellij.psi.util.PsiTreeUtil;
import com.intellij.psi.util.PsiUtil;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import com.intellij.openapi.project.DumbService;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * 单元测试生成的action
 *
 * @author chenqiong
 */
@Slf4j
public class ClassCodeGenerateAction1 extends AnAction {

    public ClassCodeGenerateAction1() {
        getTemplatePresentation().setText("generate test class");
    }

    @Override
    public void actionPerformed(@NotNull AnActionEvent e) {

        Project project = e.getProject();
//        DumbService.getInstance(project).runReadActionInSmartMode(() -> {
//        ValueContext.setEvent(e);
            ValueContext.setEvent(e);

            @Nullable VirtualFile[] files = e.getData(CommonDataKeys.VIRTUAL_FILE_ARRAY);
            if (files == null) {
                return;
            }

            for (VirtualFile file : files
            ) {
                PsiManager psiManager = PsiManager.getInstance(project);
                PsiDirectory psiDirectory = psiManager.findDirectory(file);
                Collection<PsiFile> psiFiles = PsiTreeUtil.findChildrenOfType(psiDirectory, PsiFile.class);
                for (PsiFile psiFile : psiFiles
                ) {
                    Boolean write = Boolean.TRUE;
                    FileType fileType = psiFile.getFileType();
                    if ((fileType instanceof JavaFileType)) {
                        PsiJavaFile psiJavaFile = (PsiJavaFile) psiFile;
                        PsiClass[] classes = psiJavaFile.getClasses();
                        if (classes != null && classes.length == 1) {
                            PsiClass psiClass = classes[0];
                            String filePath = FileUtils.getUnitFilePath(psiFile);
                            String fileName = FileUtils.genJavaFileName(psiClass);
                            Path path = Paths.get(filePath, fileName);
                            if (Files.exists(path)) {
                                new OpenFileDescriptor(project,
                                        LocalFileSystem.getInstance().refreshAndFindFileByPath(path.toString()))
                                        .navigate(true);
                                write = Boolean.FALSE;
                            }

                            CodeGeneratorDialog radioSelection = new CodeGeneratorDialog(psiClass);
//                        ValueContext.getContext().loadClass(psiClass);
//        radioSelection.show();
//        if (radioSelection.isOK()) {
                            if (write) {
                                String source = radioSelection.getData();
                                ValueContext.setIsJsonFileSource(source.equals("JsonFileSource"));
//                            ValueContext.setIsJsonFileSource(false);
                                // 生成java文件
//                                List<PsiField> fields = new ArrayList<PsiField>();
//                                for (PsiField psiField : psiClass.getFields()
//                                ) {
//                                    fields.add(psiField);
//                                }
//                                List<PsiMethod> methods = new ArrayList<PsiMethod>();
//                                for (PsiMethod psiMethod : psiClass.getMethods()
//                                ) {
//                                    methods.add(psiMethod);
//                                }

//                            CodeGenerator codeGenerator = new CodeGenerator(fields, methods,psiClass,psiFile);
//                            ApplicationManager.getApplication().runWriteAction(
//                                    new FileCreateTask(filePath, fileName, codeGenerator.genContent()));

                                CodeGenerator codeGenerator = new CodeGenerator(radioSelection.getFields(), radioSelection.getMethods(), psiClass, psiFile);
                                ApplicationManager.getApplication().runWriteAction(
                                        new FileCreateTask(filePath, fileName, codeGenerator.genContent(project)));
                                int a = 1;

                            }
                        }


                    }
                }
            }
//            ValueContext.setEvent(e);
//            if (Files.exists(ValueContext.getPath())) {
//                new OpenFileDescriptor(project,
//                        LocalFileSystem.getInstance().refreshAndFindFileByPath(ValueContext.getPath().toString()))
//                        .navigate(true);
//                return;
//            }
//
//            CodeGeneratorDialog radioSelection = new CodeGeneratorDialog(ValueContext.getPsiClass());
//            ValueContext.getContext().loadClass(ValueContext.getPsiClass());
////        radioSelection.show();
////        if (radioSelection.isOK()) {
//            if (true) {
//                String source = radioSelection.getData();
//                ValueContext.setIsJsonFileSource(source.equals("JsonFileSource"));
//                // 生成java文件
//                CodeGenerator codeGenerator = new CodeGenerator(radioSelection.getFields(), radioSelection.getMethods());
//                ApplicationManager.getApplication().runWriteAction(
//                        new FileCreateTask(ValueContext.getFilePath(), ValueContext.getFileName(), codeGenerator.genContent()));
//
//            }
//        });
        }



        /**
         * 只有java文件才能使用该功能
         *
         * @see AnAction#update(AnActionEvent)
         */
        @Override
        public void update (@NotNull AnActionEvent e){
            e.getPresentation().setEnabled(true);
            return;
//        super.update(e);
//        PsiFile psiFile = e.getData(CommonDataKeys.PSI_FILE);
//        FileType fileType = psiFile.getFileType();
//        if (!((fileType instanceof JavaFileType) || (fileType instanceof JavaClassFileType))) {
//            e.getPresentation().setEnabled(false);
//            return;
//        }

        }
    }
