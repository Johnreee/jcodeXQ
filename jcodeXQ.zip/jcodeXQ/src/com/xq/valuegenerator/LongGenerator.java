package com.xq.valuegenerator;

/**
 * @author 有尘
 * @date 2021/9/29
 */
public class LongGenerator extends AbstractJsonValueService<Long> {

    @Override
    public Long defaultValue() {
        return 1L;
    }

    @Override
    public Long randomValue() {
        ValueContext valueContext = new ValueContext();
        return Long.valueOf(valueContext.getFaker().number().randomNumber());
    }
}
