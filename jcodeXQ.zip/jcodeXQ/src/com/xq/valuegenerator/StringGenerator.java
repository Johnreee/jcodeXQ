package com.xq.valuegenerator;

/**
 * @author 有尘
 * @date 2021/9/29
 */
public class StringGenerator extends AbstractJsonValueService<String> {

    @Override
    public String defaultValue() {
        return "test";
    }

    @Override
    public String randomValue() {
        ValueContext valueContext = new ValueContext();
        return valueContext.getFaker().name().username();
    }
}
