package com.xq.valuegenerator;

/**
 * @author 有尘
 * @date 2021/9/29
 */
public class FloatGenerator extends AbstractJsonValueService<Float> {

    @Override
    public Float defaultValue() {
        return Float.valueOf(1.0f);
    }

    @Override
    public Float randomValue() {
        ValueContext valueContext = new ValueContext();
        return Float.valueOf(valueContext.getFaker().number().randomNumber(3, false));
    }
}
