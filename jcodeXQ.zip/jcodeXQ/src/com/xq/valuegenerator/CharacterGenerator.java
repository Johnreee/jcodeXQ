package com.xq.valuegenerator;

/**
 * @author 有尘
 * @date 2021/9/29
 */
public class CharacterGenerator extends AbstractJsonValueService<Character> {

    @Override
    public Character defaultValue() {
        return 'a';
    }

    @Override
    public Character randomValue() {
        ValueContext valueContext = new ValueContext();
        return valueContext.getFaker().lorem().character();
    }
}
