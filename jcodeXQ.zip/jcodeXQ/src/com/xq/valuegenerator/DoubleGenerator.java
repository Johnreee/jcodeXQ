package com.xq.valuegenerator;

/**
 * @author 有尘
 * @date 2021/9/29
 */
public class DoubleGenerator extends AbstractJsonValueService<Double> {

    @Override
    public Double defaultValue() {
        return Double.valueOf(1.0f);
    }

    @Override
    public Double randomValue() {
        ValueContext valueContext = new ValueContext();
        return Double.valueOf(valueContext.getFaker().number().randomNumber(3, false));
    }
}
