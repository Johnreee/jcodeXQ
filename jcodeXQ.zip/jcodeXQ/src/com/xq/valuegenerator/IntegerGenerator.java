package com.xq.valuegenerator;

/**
 * @author 有尘
 * @date 2021/9/29
 */
public class IntegerGenerator extends AbstractJsonValueService<Integer> {

    @Override
    public Integer defaultValue() {
        return 1;
    }

    @Override
    public Integer randomValue() {
        ValueContext valueContext = new ValueContext();
        return valueContext.getFaker().number().randomDigit();
    }
}
