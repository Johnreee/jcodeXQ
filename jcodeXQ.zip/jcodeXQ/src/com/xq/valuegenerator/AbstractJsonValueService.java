package com.xq.valuegenerator;

public abstract class AbstractJsonValueService<T> {
    private T score;

    public abstract  T defaultValue();

    public abstract  T randomValue();
}
